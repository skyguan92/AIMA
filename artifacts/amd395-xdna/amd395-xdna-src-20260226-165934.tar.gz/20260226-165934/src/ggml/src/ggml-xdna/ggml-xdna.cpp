#include "ggml-impl.h"
#include "ggml-backend-impl.h"
#include "ggml-cpu.h"
#include "ggml-xdna.h"

#include <cstdlib>
#include <cstring>
#include <sstream>
#include <string>
#include <filesystem>

struct ggml_backend_xdna_context {
    ggml_backend_t cpu_backend = nullptr;
    bool npu_enabled = false;
    bool npu_async = true;
    int trigger_every = 1;
    int moe_ops_seen = 0;
    int npu_failures = 0;
    std::string runner_dir;
    std::string runner_recipe;
    std::string runner_profile;
    std::string runner_mode;
};

static std::string ggml_xdna_get_env(const char * key, const std::string & def = "") {
    const char * val = std::getenv(key);
    if (!val || !*val) {
        return def;
    }
    return std::string(val);
}

static int ggml_xdna_get_env_int(const char * key, int def, int min_v = 0, int max_v = 1000000) {
    const char * val = std::getenv(key);
    if (!val || !*val) {
        return def;
    }
    char * end = nullptr;
    long v = std::strtol(val, &end, 10);
    if (!end || *end != '\0') {
        return def;
    }
    if (v < min_v) {
        return min_v;
    }
    if (v > max_v) {
        return max_v;
    }
    return (int) v;
}


static std::string ggml_xdna_join_path(const std::string & base, const std::string & name) {
    if (name.empty()) {
        return name;
    }
    std::filesystem::path p(name);
    if (p.is_absolute() || base.empty()) {
        return name;
    }
    return (std::filesystem::path(base) / p).string();
}

static bool ggml_xdna_try_run_npu(ggml_backend_xdna_context * ctx) {
    if (!ctx->npu_enabled) {
        return false;
    }

    ctx->moe_ops_seen++;
    if ((ctx->moe_ops_seen % ctx->trigger_every) != 0) {
        return false;
    }

    std::ostringstream cmd;
    cmd << "xrt-runner";
    if (!ctx->runner_recipe.empty()) {
        cmd << " --recipe '" << ggml_xdna_join_path(ctx->runner_dir, ctx->runner_recipe) << "'";
    }
    if (!ctx->runner_profile.empty()) {
        cmd << " --profile '" << ggml_xdna_join_path(ctx->runner_dir, ctx->runner_profile) << "'";
    }
    if (!ctx->runner_dir.empty()) {
        cmd << " --dir '" << ctx->runner_dir << "'";
    }
    if (!ctx->runner_mode.empty()) {
        cmd << " --mode " << ctx->runner_mode;
    }
    cmd << " >/tmp/ggml-xdna-runner.log 2>&1";
    if (ctx->npu_async) {
        cmd << " &";
    }

    const int rc = std::system(cmd.str().c_str());
    if (rc != 0 && !ctx->npu_async) {
        ctx->npu_failures++;
        GGML_LOG_WARN("ggml_xdna: xrt-runner failed (rc=%d, failures=%d), fallback remains active\n", rc, ctx->npu_failures);
        if (ctx->npu_failures >= 3) {
            ctx->npu_enabled = false;
            GGML_LOG_WARN("ggml_xdna: disabling NPU trigger after repeated failures\n");
        }
        return false;
    }

    return true;
}

static const char * ggml_backend_xdna_get_name(ggml_backend_t backend) {
    GGML_UNUSED(backend);
    return "XDNA";
}

static void ggml_backend_xdna_free(ggml_backend_t backend) {
    ggml_backend_xdna_context * ctx = (ggml_backend_xdna_context *) backend->context;
    if (ctx->cpu_backend) {
        ggml_backend_free(ctx->cpu_backend);
        ctx->cpu_backend = nullptr;
    }
    delete ctx;
    delete backend;
}

static enum ggml_status ggml_backend_xdna_graph_compute(ggml_backend_t backend, struct ggml_cgraph * cgraph) {
    ggml_backend_xdna_context * ctx = (ggml_backend_xdna_context *) backend->context;

    for (int i = 0; i < cgraph->n_nodes; i++) {
        struct ggml_tensor * node = cgraph->nodes[i];
        if (node->op == GGML_OP_MUL_MAT_ID) {
            ggml_xdna_try_run_npu(ctx);
        }
    }

    // Fallback compute path: use CPU backend for correctness.
    return ggml_backend_graph_compute(ctx->cpu_backend, cgraph);
}

static struct ggml_backend_i ggml_backend_xdna_i = {
    /* .get_name                = */ ggml_backend_xdna_get_name,
    /* .free                    = */ ggml_backend_xdna_free,
    /* .set_tensor_async        = */ NULL,
    /* .get_tensor_async        = */ NULL,
    /* .cpy_tensor_async        = */ NULL,
    /* .synchronize             = */ NULL,
    /* .graph_plan_create       = */ NULL,
    /* .graph_plan_free         = */ NULL,
    /* .graph_plan_update       = */ NULL,
    /* .graph_plan_compute      = */ NULL,
    /* .graph_compute           = */ ggml_backend_xdna_graph_compute,
    /* .event_record            = */ NULL,
    /* .event_wait              = */ NULL,
    /* .graph_optimize          = */ NULL,
};

static ggml_guid_t ggml_backend_xdna_guid(void) {
    static ggml_guid guid = { 0x1b, 0xcf, 0x32, 0x7e, 0x10, 0xa6, 0x4a, 0x6c, 0x9e, 0x5b, 0xc9, 0x7d, 0x3f, 0x11, 0xa2, 0x63 };
    return &guid;
}

ggml_backend_t ggml_backend_xdna_init(void) {
    ggml_backend_xdna_context * ctx = new ggml_backend_xdna_context;
    ctx->cpu_backend = ggml_backend_cpu_init();

    ctx->runner_dir = ggml_xdna_get_env("GGML_XDNA_RUNNER_DIR", "/home/quings/xdna-driver/src/shim_ve2/Runner/latency");
    ctx->runner_recipe = ggml_xdna_get_env("GGML_XDNA_RUNNER_RECIPE", "recipe_latency.json");
    ctx->runner_profile = ggml_xdna_get_env("GGML_XDNA_RUNNER_PROFILE", "profile_latency.json");
    ctx->runner_mode = ggml_xdna_get_env("GGML_XDNA_RUNNER_MODE", "latency");
    ctx->trigger_every = ggml_xdna_get_env_int("GGML_XDNA_TRIGGER_EVERY", 1);
    ctx->npu_async = ggml_xdna_get_env_int("GGML_XDNA_RUNNER_ASYNC", 1) != 0;
    ctx->npu_enabled = ggml_xdna_get_env_int("GGML_XDNA_RUNNER_ENABLE", 1) != 0;

    GGML_LOG_INFO("ggml_xdna: init (npu=%s, async=%s, trigger_every=%d)\n",
        ctx->npu_enabled ? "on" : "off",
        ctx->npu_async ? "on" : "off",
        ctx->trigger_every);

    ggml_backend_t backend = new ggml_backend {
        /* .guid    = */ ggml_backend_xdna_guid(),
        /* .iface   = */ ggml_backend_xdna_i,
        /* .device  = */ ggml_backend_reg_dev_get(ggml_backend_xdna_reg(), 0),
        /* .context = */ ctx,
    };

    return backend;
}

static const char * ggml_backend_xdna_device_get_name(ggml_backend_dev_t dev) {
    GGML_UNUSED(dev);
    return "XDNA";
}

static const char * ggml_backend_xdna_device_get_description(ggml_backend_dev_t dev) {
    GGML_UNUSED(dev);
    return "AMD XDNA MoE experimental backend (CPU fallback + XRT runner trigger)";
}

static void ggml_backend_xdna_device_get_memory(ggml_backend_dev_t dev, size_t * free, size_t * total) {
    GGML_UNUSED(dev);
    *free = 0;
    *total = 0;
}

static enum ggml_backend_dev_type ggml_backend_xdna_device_get_type(ggml_backend_dev_t dev) {
    GGML_UNUSED(dev);
    return GGML_BACKEND_DEVICE_TYPE_ACCEL;
}

static void ggml_backend_xdna_device_get_props(ggml_backend_dev_t dev, struct ggml_backend_dev_props * props) {
    props->name        = ggml_backend_xdna_device_get_name(dev);
    props->description = ggml_backend_xdna_device_get_description(dev);
    props->type        = ggml_backend_xdna_device_get_type(dev);
    ggml_backend_xdna_device_get_memory(dev, &props->memory_free, &props->memory_total);
    props->caps = {
        /* .async                 = */ false,
        /* .host_buffer           = */ false,
        /* .buffer_from_host_ptr  = */ true,
        /* .events                = */ false,
    };
}

static ggml_backend_t ggml_backend_xdna_device_init_backend(ggml_backend_dev_t dev, const char * params) {
    GGML_UNUSED(dev);
    GGML_UNUSED(params);
    return ggml_backend_xdna_init();
}

static ggml_backend_buffer_type_t ggml_backend_xdna_device_get_buffer_type(ggml_backend_dev_t dev) {
    GGML_UNUSED(dev);
    return ggml_backend_cpu_buffer_type();
}

static ggml_backend_buffer_t ggml_backend_xdna_device_buffer_from_host_ptr(ggml_backend_dev_t dev, void * ptr, size_t size, size_t max_tensor_size) {
    GGML_UNUSED(dev);
    GGML_UNUSED(max_tensor_size);
    return ggml_backend_cpu_buffer_from_ptr(ptr, size);
}

static bool ggml_backend_xdna_device_supports_op(ggml_backend_dev_t dev, const struct ggml_tensor * op) {
    GGML_UNUSED(dev);

    switch (op->op) {
        case GGML_OP_NONE:
        case GGML_OP_RESHAPE:
        case GGML_OP_VIEW:
        case GGML_OP_PERMUTE:
        case GGML_OP_TRANSPOSE:
            return true;
        case GGML_OP_MUL_MAT_ID:
            return true;
        default:
            return false;
    }
}

static bool ggml_backend_xdna_device_supports_buft(ggml_backend_dev_t dev, ggml_backend_buffer_type_t buft) {
    GGML_UNUSED(dev);
    return ggml_backend_buft_is_host(buft);
}

static const struct ggml_backend_device_i ggml_backend_xdna_device_i = {
    /* .get_name             = */ ggml_backend_xdna_device_get_name,
    /* .get_description      = */ ggml_backend_xdna_device_get_description,
    /* .get_memory           = */ ggml_backend_xdna_device_get_memory,
    /* .get_type             = */ ggml_backend_xdna_device_get_type,
    /* .get_props            = */ ggml_backend_xdna_device_get_props,
    /* .init_backend         = */ ggml_backend_xdna_device_init_backend,
    /* .get_buffer_type      = */ ggml_backend_xdna_device_get_buffer_type,
    /* .get_host_buffer_type = */ NULL,
    /* .buffer_from_host_ptr = */ ggml_backend_xdna_device_buffer_from_host_ptr,
    /* .supports_op          = */ ggml_backend_xdna_device_supports_op,
    /* .supports_buft        = */ ggml_backend_xdna_device_supports_buft,
    /* .offload_op           = */ NULL,
    /* .event_new            = */ NULL,
    /* .event_free           = */ NULL,
    /* .event_synchronize    = */ NULL,
};

static const char * ggml_backend_xdna_reg_get_name(ggml_backend_reg_t reg) {
    GGML_UNUSED(reg);
    return "XDNA";
}

static size_t ggml_backend_xdna_reg_get_device_count(ggml_backend_reg_t reg) {
    GGML_UNUSED(reg);
    return 1;
}

static ggml_backend_dev_t ggml_backend_xdna_reg_get_device(ggml_backend_reg_t reg, size_t index) {
    GGML_ASSERT(index == 0);

    static ggml_backend_device ggml_backend_xdna_device = {
        /* .iface   = */ ggml_backend_xdna_device_i,
        /* .reg     = */ reg,
        /* .context = */ nullptr,
    };

    return &ggml_backend_xdna_device;
}

static void * ggml_backend_xdna_get_proc_address(ggml_backend_reg_t reg, const char * name) {
    GGML_UNUSED(reg);
    GGML_UNUSED(name);
    return NULL;
}

static const struct ggml_backend_reg_i ggml_backend_xdna_reg_i = {
    /* .get_name         = */ ggml_backend_xdna_reg_get_name,
    /* .get_device_count = */ ggml_backend_xdna_reg_get_device_count,
    /* .get_device       = */ ggml_backend_xdna_reg_get_device,
    /* .get_proc_address = */ ggml_backend_xdna_get_proc_address,
};

ggml_backend_reg_t ggml_backend_xdna_reg(void) {
    static struct ggml_backend_reg ggml_backend_xdna_reg = {
        /* .api_version = */ GGML_BACKEND_API_VERSION,
        /* .iface       = */ ggml_backend_xdna_reg_i,
        /* .context     = */ NULL,
    };

    return &ggml_backend_xdna_reg;
}

GGML_BACKEND_DL_IMPL(ggml_backend_xdna_reg)