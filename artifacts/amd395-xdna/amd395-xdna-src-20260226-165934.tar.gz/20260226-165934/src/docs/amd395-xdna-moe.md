# AMD 395: llama.cpp Vulkan + XDNA MoE Experimental Path

This build adds an experimental `ggml-xdna` backend that targets `GGML_OP_MUL_MAT_ID` (MoE expert matmul op).

Current behavior:
- `MUL_MAT_ID` is scheduled to `XDNA` backend.
- Compute path remains CPU fallback for correctness.
- Backend can trigger XRT NPU runner (`xrt-runner`) on each MoE op to exercise NPU path.
- If NPU trigger fails repeatedly, backend disables NPU trigger automatically.

## Build

```bash
cmake -S . -B build-xdna -DGGML_VULKAN=ON -DGGML_XDNA=ON -DGGML_OPENCL=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-xdna -j
```

## Verify devices

```bash
./build-xdna/bin/llama-cli --list-devices
```

Expected devices include:
- `Vulkan0`
- `XDNA`

## Recommended runtime env (AMD 395)

```bash
export GGML_XDNA_RUNNER_ENABLE=1
export GGML_XDNA_RUNNER_ASYNC=1
export GGML_XDNA_TRIGGER_EVERY=8
export GGML_XDNA_RUNNER_DIR=/home/quings/xdna-driver/src/shim_ve2/Runner/latency
export GGML_XDNA_RUNNER_RECIPE=recipe_latency.json
export GGML_XDNA_RUNNER_PROFILE=profile_latency.json
export GGML_XDNA_RUNNER_MODE=latency
```

## Example run (MoE model)

```bash
./build-xdna/bin/llama-cli \
  --model /path/to/moe-model.gguf \
  --device Vulkan0,XDNA \
  --gpu-layers all \
  --ctx-size 4096 \
  --threads 16 \
  --prompt "hello"
```

## Notes

- This is an experimental bridge intended to establish a CPU+GPU+NPU execution framework on Strix Halo.
- It is not yet a true NPU matmul implementation. Real acceleration requires binary XDNA kernels for MoE GEMM and direct XRT execution integration (instead of `xrt-runner` trigger).