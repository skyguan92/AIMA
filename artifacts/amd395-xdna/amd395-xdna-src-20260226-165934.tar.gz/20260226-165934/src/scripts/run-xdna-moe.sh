#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <model.gguf> <prompt> [extra llama args...]"
  exit 1
fi

MODEL=$1
PROMPT=$2
shift 2

export GGML_XDNA_RUNNER_ENABLE=${GGML_XDNA_RUNNER_ENABLE:-1}
export GGML_XDNA_RUNNER_ASYNC=${GGML_XDNA_RUNNER_ASYNC:-1}
export GGML_XDNA_TRIGGER_EVERY=${GGML_XDNA_TRIGGER_EVERY:-8}
export GGML_XDNA_RUNNER_DIR=${GGML_XDNA_RUNNER_DIR:-/home/quings/xdna-driver/src/shim_ve2/Runner/latency}
export GGML_XDNA_RUNNER_RECIPE=${GGML_XDNA_RUNNER_RECIPE:-recipe_latency.json}
export GGML_XDNA_RUNNER_PROFILE=${GGML_XDNA_RUNNER_PROFILE:-profile_latency.json}
export GGML_XDNA_RUNNER_MODE=${GGML_XDNA_RUNNER_MODE:-latency}

exec ./build-xdna/bin/llama-cli \
  --model "$MODEL" \
  --device Vulkan0,XDNA \
  --gpu-layers all \
  --prompt "$PROMPT" \
  "$@"